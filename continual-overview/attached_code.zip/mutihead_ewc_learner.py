import math
from collections import OrderedDict

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch import autograd
from torch.autograd import Variable
from torch.utils.data import DataLoader, TensorDataset

from multihead_learner import ContinualMultiheadMLP


class ContinualMultiheadEWC(ContinualMultiheadMLP):
    def __init__(self, shared_structure, in_size, out_size, device, fisher_estimation_sample_size=16, lamda=40):
        super().__init__(shared_structure, in_size, out_size, device)
        self.fisher_estimation_sample_size = fisher_estimation_sample_size
        self.lamda = lamda
        self.fisher_dict = {}
        self.opt_dict  = {}

    def forward(self, task_data, task_id=None):
        return super(ContinualMultiheadEWC, self).forward(task_data, task_id)

    def adapt_new_task(self, task_id=None):
        super(ContinualMultiheadEWC, self).adapt_new_task(task_id)

    def get_previous_training(self, old_task_id, trainset):
        # Code from continualAI
        self.opt_dict[old_task_id] = {}
        self.fisher_dict[old_task_id] = {}
        x, y = trainset
        x = x.to(self.device)
        y = y.float().to(self.device)
        ce_loss = F.cross_entropy(self(x, task_id=old_task_id), y)
        ce_loss.backward()
        # gradients accumulated can be used to calculate fisher
        for name, param in self.shared_net.named_parameters():
            self.opt_dict[old_task_id][name] = param.data.clone()
            self.fisher_dict[old_task_id][name] = param.grad.data.clone().pow(2)

    def ewc_fisher_loss(self):
        loss = 0
        for task_id in self.fisher_dict.keys():
            for name, param in self.shared_net.named_parameters():
                fisher = self.fisher_dict[task_id][name]
                optpar = self.opt_dict[task_id][name]
                loss += (fisher * (optpar - param).pow(2)).sum()
        return loss

    def loss(self, task_data, task_labels, label_loss, task_id=None, is_test=False):
        normal_loss = label_loss(self.forward(task_data, task_id), task_labels)
        if is_test:
            return normal_loss
        else:
            ewc_loss = self.ewc_fisher_loss()
            return normal_loss + self.lamda * ewc_loss

