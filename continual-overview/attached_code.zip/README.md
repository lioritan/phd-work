Full parameter settings for main.py:

Synthetic dataset:

--train_sample_size 64 --domain 10d --n_tasks 100 --batch_size 16 --train_steps 20 --lr 0.001 --net_size 8 --kl_weight 0.01 --seed 11

CIFAR-10:

--train_sample_size 400 --domain cifar --n_tasks 150 --batch_size 32 --train_steps 20 --lr 0.001 --net_size 256 --kl_weight 0.01 --seed 11

Seeds: [42,451,1337,7834, 35932, 521588, 805287, 316882, 300]
