from avalanche.models import SimpleCNN, MultiHeadClassifier, as_multitask, MTSimpleCNN, SlimResNet18
from avalanche.benchmarks import PermutedMNIST, SplitImageNet, SplitMNIST, SplitCIFAR10, SplitInaturalist


# TODO:
# Datasets:
# Split MNIST, Split cifar10 -> class incremental (test without task id) / task incremental? (test with known task id)
# Permuted MNIST -> domain IL (transform is task dependent, all classes used in each task)
# # Split mini-Inet  -> class incremental / task incremental?

# Algorithms:
# Joint training - train on all tasks offline, upper bound
# SGD - train sequentially without countermeasures, lower bound
# EWC - known baseline
# Bayesian sequential learning (same as SGD but with KL term on each iter)

# (maybe) Learning without Forgetting (LwF) - known knowledge distillation method, minimize joint old-new loss
# Good baseline:  Classifier-projection regularization (CPR) / OGD
# Our method: If correlated, use Bayesian learning (approx Gibbs), otherwise use OGD / CPR

# measure: train loss @t, test loss @t, train forgetting, test forgetting

if __name__ == "__main__":
    pass