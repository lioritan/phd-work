import copy
import math
from collections import OrderedDict

import torch
import torch.nn as nn
import numpy as np

from common import set_random_seed
from kl_terms import get_net_densities_divergence
from multihead_learner import ContinualMultiheadMLP
from models.stochastic_layers import StochasticLinear
from mutihead_pb_learner import ContinualMultiheadPB, generate_new_network

EPS = 1e-8
LR = 1e-3


def calc_loss(data_set, is_finetuned, device, shared_model, lin_layer, model_seeds, label_loss):
    old_seed = torch.random.get_rng_state()
    task_data, task_labels = data_set
    task_data = task_data.to(device)
    task_labels = task_labels.to(device)
    losses = []
    if not is_finetuned:
        optimizer = torch.optim.Adam(lin_layer.parameters(), LR)
        optim_loss = nn.CrossEntropyLoss(reduction='mean').to(device)
        l = optim_loss(lin_layer(shared_model.forward(task_data)), task_labels.float())
        l.backward()
        optimizer.step()
    for seed in model_seeds:
        set_random_seed(seed)
        # Empirical Loss on current task:
        with torch.no_grad():
            outputs = lin_layer(shared_model.forward(task_data))
            losses.append(label_loss(outputs, task_labels))
    torch.set_rng_state(old_seed)
    return losses


class ContinualMultiheadCov(ContinualMultiheadPB):
    def __init__(self, shared_structure, in_size, out_size, device, kl_weight, delta=0.1, n_MC=3, pre_var=1e-1,
                 post_var=1e-3, adaptive_weights=False, loss_func=None):
        super().__init__(shared_structure, in_size, out_size, device, kl_weight, delta=delta, n_MC=n_MC,
                         pre_var=pre_var,
                         post_var=post_var, use_rolling_prior=False)

        self.kl_weights = {}
        self.previous_models = {}
        self.previous_lin_layers = {}
        self.is_finetuned = {}
        self.previous_train_sets = {}
        self.adaptive_weights = adaptive_weights
        self.loss_func = loss_func

    def forward(self, task_data, task_id=None):
        return super(ContinualMultiheadCov, self).forward(task_data, task_id)

    def adapt_new_task(self, task_id=None):
        old_net = generate_new_network(*self.ctor_params)
        old_net.load_state_dict(self.shared_net.state_dict())
        self.previous_models[self.max_task_id] = old_net
        self.previous_lin_layers[self.max_task_id] = copy.deepcopy(self.linear_heads)
        self.is_finetuned[self.max_task_id] = {}
        for t_id in self.linear_heads.keys():
            self.previous_lin_layers[self.max_task_id][t_id].load_state_dict(self.linear_heads[t_id].state_dict())
            self.is_finetuned[self.max_task_id][t_id] = (t_id < self.max_task_id)
        self.kl_weights[self.max_task_id] = self.kl_weight
        model_seeds = np.random.randint(9999, size=10)
        if self.adaptive_weights:
            # adaptive kl weights, train sets (perf of model i-1 on task i vs tasks i+1 onwards)
            for task_id_to_adapt in range(task_id):
                if task_id_to_adapt not in self.previous_lin_layers[task_id_to_adapt - 1]:
                    self.previous_lin_layers[task_id_to_adapt - 1][task_id_to_adapt] = nn.Linear(self.linear_layer_size,
                                                                                                 self.out_size,
                                                                                                 device=self.device)
                    self.is_finetuned[task_id_to_adapt - 1][task_id_to_adapt] = False
                loss_i = calc_loss(self.previous_train_sets[task_id_to_adapt],
                                   self.is_finetuned[task_id_to_adapt - 1][task_id_to_adapt],
                                   self.device,
                                   self.previous_models[task_id_to_adapt - 1],
                                   self.previous_lin_layers[task_id_to_adapt - 1][task_id_to_adapt],
                                   model_seeds,
                                   self.loss_func)
                self.is_finetuned[task_id_to_adapt - 1][task_id_to_adapt] = True
                #loss_i = [np.nan_to_num(1.0/self.kl_weights[task_id_to_adapt]) * l for l in loss_i]
                loss_i = [self.kl_weights[task_id_to_adapt] * l for l in loss_i]
                total_loss = [torch.tensor(0) for l in loss_i]
                for j in range(task_id_to_adapt + 1, task_id):
                    if j not in self.previous_lin_layers[task_id_to_adapt - 1]:
                        self.previous_lin_layers[task_id_to_adapt - 1][j] = nn.Linear(
                            self.linear_layer_size, self.out_size, device=self.device)
                        self.is_finetuned[task_id_to_adapt - 1][j] = False
                    loss_j = calc_loss(self.previous_train_sets[j],
                                       self.is_finetuned[task_id_to_adapt - 1][j],
                                       self.device,
                                       self.previous_models[task_id_to_adapt - 1],
                                       self.previous_lin_layers[task_id_to_adapt - 1][j],
                                       model_seeds,
                                       self.loss_func)
                    self.is_finetuned[task_id_to_adapt - 1][j] = True
                    #loss_j = [np.nan_to_num(1.0/self.kl_weights[j]) * l for l in loss_j]
                    loss_j = [self.kl_weights[j] * l for l in loss_j]
                    total_loss = [total_loss[ind] + loss_j[ind] for ind in range(len(loss_j))]
                total_cov = np.nan_to_num(np.corrcoef([np.exp(-a.cpu().item()) for a in loss_i],
                                                      [np.exp(-a.cpu().item()) for a in total_loss])[0, 1])
                if np.abs(total_cov) < EPS:
                    #pass
                    self.kl_weights[task_id_to_adapt] *= 0.5
                elif total_cov > 0:
                    self.kl_weights[task_id_to_adapt] *= 0.5 * (1 + total_cov)
                else:
                    self.kl_weights[task_id_to_adapt] *= 0.5 * (1 - np.abs(total_cov))
                    #self.kl_weights[task_id_to_adapt] = 0
        super(ContinualMultiheadCov, self).adapt_new_task(task_id)

    def get_previous_training(self, old_task_id, trainset):
        self.previous_train_sets[old_task_id] = trainset

    def loss(self, task_data, task_labels, label_loss, task_id=None, is_test=False):
        avg_empiric_loss = 0.0
        n_samples = len(task_labels)
        if is_test:
            # old_eps = self.shared_net.set_eps_std(0)
            for module in self.shared_net.modules():
                if isinstance(module, StochasticLinear):
                    old_eps = module.set_eps_std(0)
        for i_MC in range(self.n_MC):
            # Empirical Loss on current task:
            outputs = self.forward(task_data, task_id)
            avg_empiric_loss_curr = 1 * label_loss(outputs, task_labels)
            avg_empiric_loss += (1 / self.n_MC) * avg_empiric_loss_curr
        if is_test:
            # self.shared_net.set_eps_std(old_eps)
            for module in self.shared_net.modules():
                if isinstance(module, StochasticLinear):
                    module.set_eps_std(old_eps)
            return avg_empiric_loss
        total_kl = 0.0
        for old_task_id in self.kl_weights.keys():
            if old_task_id < 0:
                continue
            dvrg = get_net_densities_divergence(self.previous_models[old_task_id], self.shared_net, self.post_var,
                                                False)
            # Note: Assumes all tasks get equal sample budget, otherwise use separate n_samples per old task
            kl_term = torch.sqrt((dvrg + math.log(2 * n_samples / self.delta)) / (2 * (n_samples - 1)))
            total_kl += self.kl_weights[old_task_id] * kl_term
        return avg_empiric_loss + total_kl
