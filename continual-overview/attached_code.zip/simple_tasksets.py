import os
import random

import numpy as np
import torch
import torch.nn.functional as F
from torchvision import datasets, transforms

ANGLE_VARIANCE = 10


def get_dataset(num_samples, clf_angle, num_dims=2):
    # make a 2d dataset with clf angle
    dataset_mean = np.zeros(num_dims)
    dataset_cov = np.ones((num_dims, num_dims))
    raw_data = np.random.multivariate_normal(mean=dataset_mean, cov=dataset_cov, size=num_samples)
    if num_dims == 2:
        angle_to_slope = np.sin(clf_angle)
        dataset_labels = (raw_data[:, 1] >= angle_to_slope * raw_data[:, 0]) + 0
    else:
        angle_to_slope = np.cos(clf_angle)
        dataset_labels = (raw_data[:, 0] >= angle_to_slope * raw_data[:, 1]) + 0
    return torch.tensor(raw_data, dtype=torch.float32), \
           F.one_hot(torch.as_tensor(dataset_labels, dtype=torch.long), num_classes=2)


def get_positive_correlated_taskset(num_samples, num_tasks, num_dims=2):
    main_angle = np.random.random() * 360 - ANGLE_VARIANCE
    for i in range(num_tasks):
        yield get_dataset(num_samples, main_angle + np.random.random() * ANGLE_VARIANCE, num_dims)


def get_positive_correlated_with_distractors_taskset(num_samples, num_tasks, frac_distractors, num_dims=2):
    main_angle = np.random.random() * 360 - ANGLE_VARIANCE
    for i in range(num_tasks):
        if random.random() <= frac_distractors:  # add a distractor
            yield get_dataset(num_samples, main_angle + np.random.random() * ANGLE_VARIANCE + 180, num_dims)
        else:
            yield get_dataset(num_samples, main_angle + np.random.random() * ANGLE_VARIANCE, num_dims)


def get_gradual_shift_taskset(num_samples, num_tasks, num_dims=2):
    main_angle = np.random.random() * 360
    for i in range(num_tasks):
        yield get_dataset(num_samples, main_angle, num_dims)
        main_angle += np.random.random() * ANGLE_VARIANCE


def get_orthogonal_taskset(num_samples, num_tasks, alternating=True, num_dims=2):
    main_angle = np.random.random() * 360
    orthogonal_angle = main_angle + 90
    if alternating:
        for i in range(num_tasks):
            angle = main_angle if (i % 2 == 0) else orthogonal_angle
            yield get_dataset(num_samples, angle, num_dims)
    else:
        for i in range(num_tasks):
            angle = main_angle if (i < (num_tasks // 2)) else orthogonal_angle
            yield get_dataset(num_samples, angle, num_dims)


def get_permuted_mnist(num_samples, num_tasks, taskset_type="random", transform_type="fixed"):
    im_shape = (1, 28, 28)
    if transform_type == "fixed":
        data_transforms = [create_pixel_permute_trans(im_shape)]
    elif transform_type == "no transform":
        data_transforms = []

    if transform_type == "labels":
        target_trans = [create_label_permute_trans(10)]
    else:
        target_trans = []
    for i in range(num_tasks):
        if transform_type == "gradual":
            data_transforms += [create_limited_pixel_permute_trans(im_shape,8)]
        train_dataset, test_dataset = load_MNIST(data_transforms, "./data", target_trans=target_trans)

        assert num_samples < 2 * len(train_dataset.data) // 10
        if taskset_type == "random":
            labels = np.random.choice(np.arange(10), size=2, replace=False)
        elif taskset_type == "fixed":
            labels = [7,4]
        elif taskset_type == "alternating":
            labels = [1,7] if i%2==0 else [7,4]
        elif taskset_type == "shift":
            labels = [1, 7] if i < (num_tasks//2) else [7,4]

        label_inds = [(train_dataset.targets == l).nonzero() for l in labels]
        perms = [torch.randperm(len(inds)) for inds in label_inds]
        label_inds = [label_inds[i][perms[i][:(num_samples // 2)]] for i in range(len(labels))]
        #t_datas = [train_dataset.data[inds].flatten(1) for inds in label_inds]
        t_datas = [train_dataset.data[inds] for inds in label_inds]
        t_labels = [train_dataset.targets[inds] for inds in label_inds]
        ls = (torch.cat(t_labels) == labels[0]).long().flatten()
        yield torch.cat(t_datas, dim=0).float(), F.one_hot(ls, num_classes=2)


def load_MNIST(final_input_trans, data_path, target_trans=[]):
    # Data transformations list:
    transform = [transforms.ToTensor()]

    # Normalize values:
    # Note: original values  in the range [0,1]

    # MNIST_MEAN = (0.1307,)  # (0.5,)
    # MNIST_STD = (0.3081,)  # (0.5,)
    # transform += transforms.Normalize(MNIST_MEAN, MNIST_STD)

    transform += [transforms.Normalize((0.5,), (0.5,))]  # transform to [-1,1]

    if final_input_trans:
        transform += final_input_trans

    root_path = os.path.join(data_path, 'MNIST')

    # Train set:
    train_dataset = datasets.MNIST(root_path, train=True, download=True,
                                   transform=transforms.Compose(transform),
                                   target_transform=transforms.Compose(target_trans))

    # Test set:
    test_dataset = datasets.MNIST(root_path, train=False,
                                  transform=transforms.Compose(transform),
                                  target_transform=transforms.Compose(target_trans))

    return train_dataset, test_dataset


def create_pixel_permute_trans(input_shape):
    input_size = input_shape[0] * input_shape[1] * input_shape[2]
    inds_permute = torch.randperm(input_size)
    transform_func = lambda x: permute_pixels(x, inds_permute)
    return transform_func


def create_limited_pixel_permute_trans(input_shape, num_pixels):
    input_size = input_shape[0] * input_shape[1] * input_shape[2]
    inds_permute = torch.LongTensor(np.arange(0, input_size))

    for i_shuffle in range(num_pixels):
        i1 = np.random.randint(0, input_size)
        i2 = np.random.randint(0, input_size)
        temp = inds_permute[i1]
        inds_permute[i1] = inds_permute[i2]
        inds_permute[i2] = temp

    transform_func = lambda x: permute_pixels(x, inds_permute)
    return transform_func


def create_label_permute_trans(n_class):
    inds_permute = torch.randperm(n_class)
    transform_func = lambda target: inds_permute[target]
    return transform_func


def permute_pixels(x, inds_permute):
    ''' Permute pixels of a tensor image'''
    im_H = x.shape[1]
    im_W = x.shape[2]
    input_size = im_H * im_W
    x = x.view(input_size)  # flatten image
    x = x[inds_permute]
    x = x.view(1, im_H, im_W)
    return x

CIFAR_DISTRACT = 0.2

def get_cifar_taskset(num_samples, num_tasks, taskset_type="fixed"):
    data_transforms = []
    target_trans = []
    for i in range(num_tasks):
        train_dataset, test_dataset = load_cifar(data_transforms, "./data", target_trans=target_trans)
        assert num_samples < 2 * len(train_dataset.data) // 10
        if taskset_type == "random":
            labels = np.random.choice(np.arange(10), size=2, replace=False)
        elif taskset_type == "fixed":
            labels = [1,9]
        elif taskset_type == "alternating":
            labels = [1,9] if i % 2 == 0 else [3,5]
        elif taskset_type == "shift":
            labels = [1, 9] if i < (num_tasks//2) else [3, 5]
        elif taskset_type == "distractors_20%":
            labels = [1,9]
        #     false_labels = [3,5]
        trainloader = torch.utils.data.DataLoader(train_dataset, batch_size=len(train_dataset.data),
                                                  shuffle=False)
        for d,t in trainloader:
            targs = t
            data_ = d
        label_inds = [(targs == l).nonzero().flatten() for l in labels]
        perms = [torch.randperm(len(inds)) for inds in label_inds]
        label_inds = [label_inds[i][perms[i][:(num_samples // 2)]] for i in range(len(labels))]
        t_datas = [data_[inds].flatten(1) for inds in label_inds]
        #t_datas = [data_[inds] for inds in label_inds]
        t_labels = [targs[inds] for inds in label_inds]
        if taskset_type == "distractors_20%" and random.random() >= CIFAR_DISTRACT:
            ls = (torch.cat(t_labels) != labels[0]).long().flatten()
        else:
            ls = (torch.cat(t_labels) == labels[0]).long().flatten()
        yield torch.cat(t_datas, dim=0).float(), F.one_hot(ls, num_classes=2)


def load_cifar(final_input_trans, data_path, target_trans=[]):
    # Data transformations list:
    transform = [transforms.ToTensor()]
    transform += [transforms.Normalize((0.5,0.5,0.5,), (0.5,0.5,0.5, ))]  # transform to [-1,1]

    if final_input_trans:
        transform += final_input_trans

    root_path = os.path.join(data_path, 'CIFAR10')

    # Train set:
    train_dataset = datasets.CIFAR10(root_path, train=True, download=False,
                                   transform=transforms.Compose(transform),
                                   target_transform=transforms.Compose(target_trans))

    # Test set:
    test_dataset = datasets.CIFAR10(root_path, train=False,
                                  transform=transforms.Compose(transform),
                                  target_transform=transforms.Compose(target_trans))

    return train_dataset, test_dataset