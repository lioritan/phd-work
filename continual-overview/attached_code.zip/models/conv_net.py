from models.layer_inits import init_layers
from models.stochastic_layers import StochasticLayer
import torch.nn as nn
import torch.nn.functional as F
import torch


def get_size_of_conv_output(input_shape, conv_func):
    # generate dummy input sample and forward to get shape after conv layers
    batch_size = 1
    input = torch.rand(batch_size, *input_shape, device="cuda:0")
    output_feat = conv_func(input)
    conv_out_size = output_feat.data.view(batch_size, -1).size(1)
    return conv_out_size


class general_model(nn.Module):
    def __init__(self):
        super(general_model, self).__init__()

    def set_eps_std(self, eps_std):
        old_eps_std = None
        for m in self.modules():
            if isinstance(m, StochasticLayer):
                old_eps_std = m.set_eps_std(eps_std)
        return old_eps_std

    def _init_weights(self, log_var_init):
        init_layers(self, log_var_init)


class ConvNet3(general_model):
    def __init__(self, conv2d_layer, input_shape, device, n_filt1=8, n_filt2=64):
        super(ConvNet3, self).__init__()
        color_channels = input_shape[0]
        self.conv1 = conv2d_layer(color_channels, n_filt1, kernel_size=5)
        self.conv2 = conv2d_layer(n_filt1, n_filt2, kernel_size=3)
        self.conv3 = conv2d_layer(n_filt2, n_filt2, kernel_size=3)
        self.conv1.to(device)
        self.conv2.to(device)
        self.conv3.to(device)
        self.conv_feat_size = get_size_of_conv_output(input_shape, self._forward_features)

    def _forward_features(self, x):
        x = F.elu(F.max_pool2d(self.conv1(x), 2))
        #x = F.elu(F.max_pool2d(self.conv2(x), 2))
        #x = F.elu(F.max_pool2d(self.conv3(x), 2))
        return x

    def forward(self, x):
        x = self._forward_features(x)
        x = x.view(x.size(0), -1)
        return x
