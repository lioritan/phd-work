import copy
import math
from collections import OrderedDict

import torch
import torch.nn as nn
import numpy as np

from common import set_random_seed
from kl_terms import get_net_densities_divergence
from multihead_learner import ContinualMultiheadMLP
from models.stochastic_layers import StochasticLinear
from mutihead_pb_learner import ContinualMultiheadPB, generate_new_network

EPS = 1e-8
LR = 1e-3


def calc_loss(data_set, is_finetuned, device, shared_model, lin_layer, model_seeds, label_loss):
    old_seed = torch.random.get_rng_state()
    task_data, task_labels = data_set
    task_data = task_data.to(device)
    task_labels = task_labels.to(device)
    losses = []
    if not is_finetuned:
        optimizer = torch.optim.Adam(lin_layer.parameters(), LR)
        optim_loss = nn.CrossEntropyLoss(reduction='mean').to(device)
        l = optim_loss(lin_layer(shared_model.forward(task_data)), task_labels.float())
        l.backward()
        optimizer.step()
    for seed in model_seeds:
        set_random_seed(seed)
        # Empirical Loss on current task:
        with torch.no_grad():
            outputs = lin_layer(shared_model.forward(task_data))
            losses.append(label_loss(outputs, task_labels))
    torch.set_rng_state(old_seed)
    return losses


class ContinualMultiheadFilter(ContinualMultiheadPB):
    def __init__(self, shared_structure, in_size, out_size, device, kl_weight, delta=0.1, n_MC=3, pre_var=1e-1,
                 post_var=1e-3, k=5, loss_threshold=1, keep_all=False, keep_only_aligned=False, loss_func=None):
        super().__init__(shared_structure, in_size, out_size, device, kl_weight, delta=delta, n_MC=n_MC,
                         pre_var=pre_var,
                         post_var=post_var, use_rolling_prior=False)

        self.kl_weights = {}
        self.previous_models = {}
        self.is_finetuned = {}
        self.previous_train_set = []
        self.k = k
        self.keep_all = keep_all
        self.keep_only_aligned = keep_only_aligned
        self.loss_func = loss_func
        self.loss_threshold = loss_threshold

    def forward(self, task_data, task_id=None):
        return super(ContinualMultiheadFilter, self).forward(task_data, task_id)

    def save_previous_model(self, old_net):
        self.previous_models[self.max_task_id] = old_net
        self.kl_weights[self.max_task_id] = self.kl_weight

    def adapt_new_task(self, task_id=None):
        old_net = generate_new_network(*self.ctor_params)
        old_net.load_state_dict(self.shared_net.state_dict())
        if self.keep_all or len(self.previous_train_set) < 2 or self.max_task_id==0:
            self.save_previous_model(old_net)
        else:
            model_seeds = np.random.randint(9999, size=10)
            old_train_set = self.previous_train_set[0]
            curr_train_set = self.previous_train_set[1]
            old_losses = calc_loss(old_train_set, True, self.device, old_net,
                                   self.linear_heads[self.max_task_id - 1], model_seeds, self.loss_func)
            custom_linear = nn.Linear(self.linear_layer_size, self.out_size, device=self.device)
            new_losses = calc_loss(curr_train_set, False, self.device, old_net,
                                   custom_linear, model_seeds, self.loss_func)
            # expected_diff = 0.0
            # for ind in range(len(model_seeds)):
            #     expected_diff += np.exp(np.nan_to_num(1.0 / self.kl_weight) * (old_losses[ind] - new_losses[ind]))
            # expected_diff /= len(model_seeds)
            new_losses = np.array([l.cpu() for l in new_losses])
            old_losses = np.array([l.cpu() for l in old_losses])
            loss_diffs = old_losses - new_losses
            #if expected_diff <= 1:  # log expectation is at most zero, either tasks aligned or source is good
            if (loss_diffs <= 0).all():  # log expectation is at most zero, either tasks aligned or source is good
                if self.keep_only_aligned and np.mean(new_losses) >= self.loss_threshold:
                    pass  # source loss is low, target loss is high, no alignment
                else:
                    self.save_previous_model(old_net)

        if len(self.kl_weights.keys()) > self.k:
            lowest_key = np.min(list(self.kl_weights.keys()))
            self.kl_weights.pop(lowest_key)
            self.previous_models.pop(lowest_key)
        super(ContinualMultiheadFilter, self).adapt_new_task(task_id)

    def get_previous_training(self, old_task_id, trainset):
        if len(self.previous_train_set) > 1:
            self.previous_train_set.pop(0)
        self.previous_train_set.append(trainset)

    def loss(self, task_data, task_labels, label_loss, task_id=None, is_test=False):
        avg_empiric_loss = 0.0
        n_samples = len(task_labels)
        if is_test:
            # old_eps = self.shared_net.set_eps_std(0)
            for module in self.shared_net.modules():
                if isinstance(module, StochasticLinear):
                    old_eps = module.set_eps_std(0)
        for i_MC in range(self.n_MC):
            # Empirical Loss on current task:
            outputs = self.forward(task_data, task_id)
            avg_empiric_loss_curr = 1 * label_loss(outputs, task_labels)
            avg_empiric_loss += (1 / self.n_MC) * avg_empiric_loss_curr
        if is_test:
            # self.shared_net.set_eps_std(old_eps)
            for module in self.shared_net.modules():
                if isinstance(module, StochasticLinear):
                    module.set_eps_std(old_eps)
            return avg_empiric_loss
        total_kl = 0.0
        for old_task_id in self.kl_weights.keys():
            dvrg = get_net_densities_divergence(self.previous_models[old_task_id], self.shared_net, self.post_var,
                                                False)
            # Note: Assumes all tasks get equal sample budget, otherwise use separate n_samples per old task
            kl_term = torch.sqrt((dvrg + math.log(2 * n_samples / self.delta)) / (2 * (n_samples - 1)))
            total_kl += self.kl_weights[old_task_id] * kl_term
        return avg_empiric_loss + total_kl
