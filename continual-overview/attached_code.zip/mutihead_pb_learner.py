import math
from collections import OrderedDict

import torch
import torch.nn as nn

from kl_terms import get_net_densities_divergence
from multihead_learner import ContinualMultiheadMLP
from models.stochastic_layers import StochasticLinear, StochasticConv2d


def generate_new_network(shared_structure, in_size, out_size, pre_var, device):
    net_struct = []
    for i, layer in enumerate(shared_structure):
        log_vars = {"mean": 0.0, "std": pre_var}
        linear = StochasticLinear(in_dim=shared_structure[i - 1] if i > 0 else in_size,
                                  out_dim=layer,
                                  log_var_init=log_vars)
        linear.to(device=device)
        net_struct.append((f"layer{i}", linear))
        net_struct.append((f"activation{i}", nn.ELU()))
    shared_net = nn.Sequential(OrderedDict(net_struct))
    return shared_net


def get_conv_layer(in_channels, out_channels, kernel_size):
    return StochasticConv2d(in_channels, out_channels, kernel_size, log_var_init={"mean": 0.0, "std": 0.005},
                            use_bias=True)


class ContinualMultiheadPB(ContinualMultiheadMLP):
    def __init__(self, shared_structure, in_size, out_size, device, kl_weight, delta=0.1, n_MC=3, pre_var=5e-3,
                 post_var=1e-3, use_rolling_prior=False):
        super().__init__(shared_structure, in_size, out_size, device)
        net_struct = []
        for i, layer in enumerate(shared_structure):
            log_vars = {"mean": 0.0, "std": pre_var}
            linear = StochasticLinear(in_dim=shared_structure[i - 1] if i > 0 else in_size,
                                      out_dim=layer,
                                      log_var_init=log_vars)
            linear.to(device=device)
            net_struct.append((f"layer{i}", linear))
            net_struct.append((f"activation{i}", nn.ReLU()))
        self.shared_net = nn.Sequential(OrderedDict(net_struct))
        self.prior = nn.Sequential(OrderedDict(net_struct))
        self.prior.load_state_dict(self.shared_net.state_dict())

        self.use_rolling_prior = use_rolling_prior
        self.ctor_params = [shared_structure, in_size, out_size, pre_var, device]

        self.delta = delta
        self.n_MC = n_MC
        self.kl_weight = kl_weight
        self.post_var = post_var

    def forward(self, task_data, task_id=None):
        return super(ContinualMultiheadPB, self).forward(task_data, task_id)

    def adapt_new_task(self, task_id=None):
        if self.use_rolling_prior:
            self.prior = generate_new_network(*self.ctor_params)
            self.prior.load_state_dict(self.shared_net.state_dict())
        super(ContinualMultiheadPB, self).adapt_new_task(task_id)

    def get_previous_training(self, old_task_id, trainset):
        pass

    def loss(self, task_data, task_labels, label_loss, task_id=None, is_test=False):
        avg_empiric_loss = 0.0
        n_samples = len(task_labels)
        if is_test:
            for module in self.shared_net.modules():
                if isinstance(module, StochasticLinear):
                    old_eps = module.set_eps_std(0)
        for i_MC in range(self.n_MC):
            # Empirical Loss on current task:
            outputs = self.forward(task_data, task_id)
            avg_empiric_loss_curr = 1 * label_loss(outputs, task_labels)
            avg_empiric_loss += (1 / self.n_MC) * avg_empiric_loss_curr
        dvrg = get_net_densities_divergence(self.prior, self.shared_net, self.post_var, False)
        kl_term = torch.sqrt((dvrg + math.log(2 * n_samples / self.delta)) / (2 * (n_samples - 1)))
        if is_test:
            for module in self.shared_net.modules():
                if isinstance(module, StochasticLinear):
                    module.set_eps_std(old_eps)
            return avg_empiric_loss
        return avg_empiric_loss + self.kl_weight * kl_term
