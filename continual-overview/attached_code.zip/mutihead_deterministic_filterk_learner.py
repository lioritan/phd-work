import torch
import torch.nn as nn
import numpy as np

import multihead_learner
from multihead_learner import ContinualMultiheadMLP

LR = 1e-3


def calc_loss(data_set, is_finetuned, device, shared_model, lin_layer, label_loss):
    task_data, task_labels = data_set
    task_data = task_data.to(device)
    task_labels = task_labels.to(device)
    if not is_finetuned:
        optimizer = torch.optim.Adam(lin_layer.parameters(), LR)
        optim_loss = nn.CrossEntropyLoss(reduction='mean').to(device)
        l = optim_loss(lin_layer(shared_model.forward(task_data)), task_labels.float())
        l.backward()
        optimizer.step()
    # Empirical Loss on current task:
    with torch.no_grad():
        outputs = lin_layer(shared_model.forward(task_data))
        return label_loss(outputs, task_labels)


class ContinualMultiheadDeterministicNNFilterK(ContinualMultiheadMLP):
    def __init__(self, shared_structure, in_size, out_size, device, kl_weight=40,
                 k=5, loss_threshold=1, keep_all=False, keep_only_aligned=False, loss_func=None):
        super().__init__(shared_structure, in_size, out_size, device)
        self.opt_dict = {}
        self.prev_opts = {}
        self.k = k
        self.kl_weight = kl_weight
        self.keep_all = keep_all
        self.keep_only_aligned = keep_only_aligned
        self.loss_func = loss_func
        self.loss_threshold = loss_threshold
        self.prev_training = []
        self.net_clone_params = [shared_structure, device, in_size]

    def forward(self, task_data, task_id=None):
        return super(ContinualMultiheadDeterministicNNFilterK, self).forward(task_data, task_id)

    def adapt_new_task(self, task_id=None):
        if not self.keep_all and len(self.prev_training) == 2 and self.max_task_id > 0:
            old_train_set = self.prev_training[0]
            curr_train_set = self.prev_training[1]
            old_loss = calc_loss(old_train_set, True, self.device, self.prev_opts[self.max_task_id - 1],
                                 self.linear_heads[self.max_task_id - 1], self.loss_func)
            custom_linear = nn.Linear(self.linear_layer_size, self.out_size, device=self.device)
            new_loss = calc_loss(curr_train_set, False, self.device, self.prev_opts[self.max_task_id - 1],
                                 custom_linear, self.loss_func)
            if old_loss > new_loss:
                self.opt_dict.pop(self.max_task_id - 1)
                self.prev_opts.pop(self.max_task_id - 1)
            else:
                if self.keep_only_aligned and new_loss >= self.loss_threshold:
                    self.opt_dict.pop(self.max_task_id - 1)
                    self.prev_opts.pop(self.max_task_id - 1)
        if len(self.opt_dict.keys()) > self.k:
            lowest_key = np.min(list(self.opt_dict.keys()))
            self.opt_dict.pop(lowest_key)
            self.prev_opts.pop(lowest_key)
        super(ContinualMultiheadDeterministicNNFilterK, self).adapt_new_task(task_id)

    def get_previous_training(self, old_task_id, trainset):
        self.opt_dict[old_task_id] = {}
        if len(self.prev_training) > 1:
            self.prev_training.pop(0)
        self.prev_training.append(trainset)
        # clone net
        self.prev_opts[old_task_id] = multihead_learner.build_shared_net(*self.net_clone_params)
        self.prev_opts[old_task_id].load_state_dict(self.shared_net.state_dict())
        for name, param in self.shared_net.named_parameters():
            self.opt_dict[old_task_id][name] = param.data.clone()

    def regularization_loss(self):
        loss = 0
        for task_id in self.opt_dict.keys():
            for name, param in self.shared_net.named_parameters():
                optpar = self.opt_dict[task_id][name]
                loss += (optpar - param).pow(2).sum()
        return loss

    def loss(self, task_data, task_labels, label_loss, task_id=None, is_test=False):
        normal_loss = label_loss(self.forward(task_data, task_id), task_labels)
        if is_test:
            return normal_loss
        else:
            regularization_loss = self.regularization_loss()
            return normal_loss + self.kl_weight * regularization_loss
