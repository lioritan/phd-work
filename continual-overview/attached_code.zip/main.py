import argparse
import pickle

import torch
import torch.nn as nn
import numpy as np
from torch.utils.data import random_split, Dataset, TensorDataset, DataLoader
from torchmetrics import Accuracy
import matplotlib.pyplot as plt

from common import set_random_seed
from multihead_learner import ContinualMultiheadMLP
from mutihead_cov_learner import ContinualMultiheadCov
from mutihead_deterministic_filterk_learner import ContinualMultiheadDeterministicNNFilterK
from mutihead_ewc_learner import ContinualMultiheadEWC
from mutihead_filterk_learner import ContinualMultiheadFilter
from mutihead_pb_learner import ContinualMultiheadPB
from simple_tasksets import get_positive_correlated_taskset, get_positive_correlated_with_distractors_taskset, \
    get_gradual_shift_taskset, get_orthogonal_taskset, get_permuted_mnist, get_cifar_taskset


def train_models(models, loss_function, task_id, learning_rate, n_epochs, trn_loader, device):
    model_params = [list(m.shared_net.parameters()) + list(m.linear_heads[task_id].parameters()) for m in models]
    model_optimizers = [torch.optim.Adam(m_params, lr=learning_rate) for m_params in model_params]
    for iter in range(n_epochs):
        for task_data, task_labels in trn_loader:
            task_data = task_data.to(device)
            task_labels = task_labels.to(device)

            for i, model in enumerate(models):
                model_optimizers[i].zero_grad()
                train_acc = model.loss(task_data, task_labels.float(), loss_function, task_id=task_id, is_test=False)
                train_acc.backward()
                model_optimizers[i].step()
                model_optimizers[i].zero_grad()  # just for EWC


def get_bwt_losses(models, task_list, device):
    totals = [0.0 for m in models]
    acc_function = Accuracy("binary").to(device)
    for j, data_set in enumerate(task_list):
        task_data, task_labels = data_set
        task_data = task_data.to(device)
        task_labels = task_labels.to(device)
        with torch.no_grad():
            for m_index, m in enumerate(models):
                totals[m_index] += m.loss(task_data, task_labels, acc_function, task_id=j, is_test=True).to("cpu")
    return totals


def get_parser():
    parser = argparse.ArgumentParser()
    parser.add_argument('--train_sample_size', default=400, type=int,
                        help="Number of training examples in each task")
    parser.add_argument('--domain', default="cifar", type=str,
                        help="Problem domain: 2d, 10d, mnist, cifar")
    parser.add_argument('--n_tasks', default=150, type=int,
                        help="Number of tasks")
    parser.add_argument('--batch_size', default=32, type=int,
                        help="Gradient batch size")
    parser.add_argument('--train_steps', default=20, type=int,
                        help="Total grad updates in training")
    parser.add_argument('--lr', default=1e-3, type=float,
                        help="Learning rate")
    parser.add_argument('--net_size', default=256, type=int,
                        help="Shared net size")
    parser.add_argument('--kl_weight', default=1e-2, type=float,
                        help="KL lambda")
    parser.add_argument('--seed', type=int, default=300, help="Random seed")
    # [42, 11, 7834, 451, 1337]
    # [35932, 521588, 805287, 316882, 300]
    return parser


if __name__ == "__main__":
    args = get_parser().parse_args()
    set_random_seed(args.seed)
    # simple tasksets, the 3 simple learners, measure stuff
    n_samples = args.train_sample_size
    n_tasks = args.n_tasks
    network_structure = [args.net_size]
    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    acc = Accuracy("binary").to(device)
    zero_one_loss = lambda out, expected: 1 - acc(out, expected)
    exp_name = "thresh0.3"
    task_dict = {}
    if args.domain == "2d":
        task_dict["positive_correlation"] = get_positive_correlated_taskset(n_samples, n_tasks)
        task_dict["distractors"] = get_positive_correlated_with_distractors_taskset(n_samples, n_tasks,
                                                                                    frac_distractors=0.2)
        task_dict["gradual_shift"] = get_gradual_shift_taskset(n_samples, n_tasks)
        task_dict["orthogonal_alternating"] = get_orthogonal_taskset(n_samples, n_tasks, alternating=True)
        task_dict["orthogonal_shift"] = get_orthogonal_taskset(n_samples, n_tasks, alternating=False)
        DIMS = 2
    elif args.domain == "10d":
        task_dict["positive_correlation_10d"] = get_positive_correlated_taskset(n_samples, n_tasks, num_dims=10)
        task_dict["distractors_10d"] = get_positive_correlated_with_distractors_taskset(n_samples, n_tasks,
                                                                                        frac_distractors=0.2,
                                                                                        num_dims=10)
        task_dict["gradual_shift_10d"] = get_gradual_shift_taskset(n_samples, n_tasks, num_dims=10)
        task_dict["orthogonal_alternating_10d"] = get_orthogonal_taskset(n_samples, n_tasks, alternating=True,
                                                                         num_dims=10)
        task_dict["orthogonal_shift_10d"] = get_orthogonal_taskset(n_samples, n_tasks, alternating=False, num_dims=10)
        DIMS = 10
    elif args.domain == "mnist":
        task_dict["permuted_mnist_none"] = get_permuted_mnist(n_samples, n_tasks, taskset_type="random",
                                                              transform_type="no transform")
        task_dict["permuted_mnist_fixed"] = get_permuted_mnist(n_samples, n_tasks, taskset_type="random",
                                                               transform_type="fixed")
        task_dict["permuted_mnist_gradual"] = get_permuted_mnist(n_samples, n_tasks, taskset_type="random",
                                                                 transform_type="gradual")
        task_dict["permuted_mnist_label"] = get_permuted_mnist(n_samples, n_tasks, taskset_type="random",
                                                               transform_type="labels")
        task_dict["permuted_mnist_const"] = get_permuted_mnist(n_samples, n_tasks, taskset_type="fixed",
                                                               transform_type="fixed")
        task_dict["permuted_mnist_alt"] = get_permuted_mnist(n_samples, n_tasks, taskset_type="alternating",
                                                             transform_type="fixed")
        task_dict["permuted_mnist_shift"] = get_permuted_mnist(n_samples, n_tasks, taskset_type="shift",
                                                               transform_type="fixed")
        # TODO: more explicit distractors tasks? which ones matter? wrong labels? white noise?
        DIMS = 28 ** 2
    elif args.domain == "cifar":
        task_dict["cifar10_static"] = get_cifar_taskset(n_samples, n_tasks, taskset_type="fixed")
        task_dict["cifar10_distractors"] = get_cifar_taskset(n_samples, n_tasks, taskset_type="distractors_20%")
        task_dict["cifar10_random"] = get_cifar_taskset(n_samples, n_tasks, taskset_type="random")
        # task_dict["cifar10_alternating"] = get_cifar_taskset(n_samples, n_tasks, taskset_type="alternating")
        task_dict["cifar10_shift"] = get_cifar_taskset(n_samples, n_tasks, taskset_type="shift")
        DIMS = 3 * (32 ** 2)
    else:
        raise ValueError(f"Not supported domain {args.domain}")

    for task_name, task_gen in task_dict.items():
        task_list = [task for task in task_gen]

        sgd_model = ContinualMultiheadMLP(shared_structure=network_structure, in_size=DIMS, out_size=2, device=device)
        pb_model = ContinualMultiheadPB(shared_structure=network_structure, in_size=DIMS, out_size=2, device=device,
                                        kl_weight=args.kl_weight)
        pb_averaged = ContinualMultiheadCov(shared_structure=network_structure, in_size=DIMS, out_size=2, device=device,
                                            kl_weight=args.kl_weight, adaptive_weights=False)
        pb_adaptive = ContinualMultiheadCov(shared_structure=network_structure, in_size=DIMS, out_size=2, device=device,
                                            kl_weight=args.kl_weight, adaptive_weights=True,
                                            loss_func=zero_one_loss)
        pb_last_k = ContinualMultiheadFilter(shared_structure=network_structure, in_size=DIMS, out_size=2,
                                             device=device,
                                             kl_weight=args.kl_weight, keep_all=True, )
        pb_aligned_k = ContinualMultiheadFilter(shared_structure=network_structure, in_size=DIMS, out_size=2,
                                                device=device,
                                                kl_weight=args.kl_weight, keep_all=False, keep_only_aligned=True,
                                                loss_func=zero_one_loss, loss_threshold=0.1)
        pb_good_k = ContinualMultiheadFilter(shared_structure=network_structure, in_size=DIMS, out_size=2,
                                             device=device,
                                             kl_weight=args.kl_weight, keep_all=False, keep_only_aligned=False,
                                             loss_func=zero_one_loss)
        pb_aligned_1 = ContinualMultiheadFilter(shared_structure=network_structure, in_size=DIMS, out_size=2,
                                                device=device, k=1,
                                                kl_weight=args.kl_weight, keep_all=False, keep_only_aligned=True,
                                                loss_func=zero_one_loss, loss_threshold=0.1)
        pb_good_1 = ContinualMultiheadFilter(shared_structure=network_structure, in_size=DIMS, out_size=2,
                                             device=device, k=1,
                                             kl_weight=args.kl_weight, keep_all=False, keep_only_aligned=False,
                                             loss_func=zero_one_loss)
        ewc = ContinualMultiheadEWC(shared_structure=network_structure, in_size=DIMS, out_size=2,
                                    device=device, lamda=40)
        sgd_last_k = ContinualMultiheadDeterministicNNFilterK(shared_structure=network_structure, in_size=DIMS,
                                                              out_size=2,
                                                              device=device,
                                                              kl_weight=args.kl_weight, keep_all=True, )
        sgd_aligned_k = ContinualMultiheadDeterministicNNFilterK(shared_structure=network_structure, in_size=DIMS,
                                                                 out_size=2,
                                                                 device=device,
                                                                 kl_weight=args.kl_weight, keep_all=False,
                                                                 keep_only_aligned=True,
                                                                 loss_func=zero_one_loss, loss_threshold=0.3)
        sgd_good_k = ContinualMultiheadDeterministicNNFilterK(shared_structure=network_structure, in_size=DIMS,
                                                                 out_size=2,
                                                                 device=device,
                                                                 kl_weight=args.kl_weight, keep_all=False,
                                                                 keep_only_aligned=False,
                                                                 loss_func=zero_one_loss)
        sgd_aligned_1 = ContinualMultiheadDeterministicNNFilterK(shared_structure=network_structure, in_size=DIMS,
                                                                 out_size=2, k=1,
                                                                 device=device,
                                                                 kl_weight=args.kl_weight, keep_all=False,
                                                                 keep_only_aligned=True,
                                                                 loss_func=zero_one_loss, loss_threshold=0.3)
        sgd_good_1 = ContinualMultiheadDeterministicNNFilterK(shared_structure=network_structure, in_size=DIMS,
                                                                 out_size=2, k=1,
                                                                 device=device,
                                                                 kl_weight=args.kl_weight, keep_all=False,
                                                                 keep_only_aligned=False,
                                                                 loss_func=zero_one_loss)
        sgd_last_all = ContinualMultiheadDeterministicNNFilterK(shared_structure=network_structure, in_size=DIMS,
                                                              out_size=2, k=n_tasks,
                                                              device=device,
                                                              kl_weight=args.kl_weight, keep_all=True, )

        model_dict = {"SGD": sgd_model,
                      "EWC": ewc,
                      #"Static prior": pb_model,
                      #"Averaged KL": pb_averaged,
                      #"Adaptive average (ours)": pb_adaptive,
                      #"Last 5 priors": pb_last_k,
                      #"Aligned 5 priors (ours)": pb_aligned_k,
                      #"Conditioned 5 priors (ours)": pb_good_k,
                      #"Aligned 1 prior (ours)": pb_aligned_1,
                      #"Conditioned 1 prior (ours)": pb_good_1,
                      "SGD Last 5 priors": sgd_last_k,
                      "SGD Aligned 5 priors (ours)": sgd_aligned_k,
                      "SGD Conditioned 5 priors (ours)": sgd_good_k,
                      #"SGD Aligned 1 prior (ours)": sgd_aligned_1,
                      #"SGD Conditioned 1 prior (ours)": sgd_good_1,
                      #"keep all priors": sgd_last_all,
                      }
        trn_frac = 0.8
        loss_function = nn.CrossEntropyLoss(reduction='mean').to(device)
        acc_function = Accuracy("binary").to(device)
        batch_size = args.batch_size
        n_train_epochs = args.train_steps
        learning_rate = args.lr

        train_sets = []
        test_sets = []
        test_accs = {}
        test_bwts = {}
        for model_name in model_dict.keys():
            test_accs[model_name] = []
            test_bwts[model_name] = []
        for i, task in enumerate(task_list):
            trn, tst = random_split(TensorDataset(task[0], task[1]),
                                    [int(n_samples * trn_frac), n_samples - int(n_samples * trn_frac)])
            trn_loader = DataLoader(trn, batch_size=batch_size, shuffle=True)
            for model in model_dict.values():
                if isinstance(model, ContinualMultiheadFilter):  # needs current training set
                    train_loader = DataLoader(trn, batch_size=int(n_samples * trn_frac))
                    for trn_set_i in train_loader:
                        model.get_previous_training(i, trn_set_i)
                model.adapt_new_task(i)
            train_models(model_dict.values(), loss_function, i, learning_rate, n_train_epochs, trn_loader, device)

            # Record test losses (generalization)
            test_loader = DataLoader(tst, batch_size=n_samples - int(n_samples * trn_frac))
            for test_data, test_labels in test_loader:
                test_data = test_data.to(device)
                test_labels = test_labels.to(device)
                with torch.no_grad():
                    for model_name, model in model_dict.items():
                        test_accs[model_name].append(
                            model.loss(test_data, test_labels, acc_function, task_id=i, is_test=True).to("cpu").numpy())

            # Record test forgetting
            test_forgettings = get_bwt_losses(model_dict.values(), test_sets, device)
            if i > 0:
                for j, model_name in enumerate(model_dict.keys()):
                    test_bwts[model_name].append(test_forgettings[j])

            test_loader = DataLoader(tst, batch_size=n_samples - int(n_samples * trn_frac))
            for test_set_i in test_loader:
                test_sets.append(test_set_i)
            train_loader = DataLoader(trn, batch_size=int(n_samples * trn_frac))
            for trn_set_i in train_loader:
                train_sets.append(trn_set_i)
                for model in model_dict.values():
                    model.get_previous_training(i, trn_set_i)

        with open(f"accuracies_{exp_name}_{args.domain}_{task_name}_{args.seed}.pkl", "wb") as fptr:
            pickle.dump((test_accs, test_bwts), fptr)

        # Show plots
        plt.figure()
        for model_name in model_dict.keys():
            plt.scatter(range(n_tasks), np.cumsum(test_accs[model_name]) / np.arange(1, n_tasks + 1),
                        label=f"{model_name}")

        plt.legend()
        plt.xlabel("Task number")
        plt.ylabel("Averaged test accuracy")
        plt.savefig(f"test_errors_{exp_name}_{task_name}.jpg")
        for model_name in model_dict.keys():
            print(
                f"{task_name}, {model_name} avg acc: {np.mean(test_accs[model_name])}, final backwards acc: {test_bwts[model_name][-1] / (n_tasks - 1)}")
        for model_name in model_dict.keys():
            print(
                f"{task_name}, {model_name} last 5 acc: {np.mean(test_accs[model_name][-5:])}, bwts: {np.mean(test_bwts[model_name][-5:] / np.arange(n_tasks - 5, n_tasks))}")

        plt.figure()
        for model_name in model_dict.keys():
            plt.scatter(range(1, n_tasks), test_bwts[model_name] / np.arange(1, n_tasks), label=f"{model_name}")
        # plt.scatter(range(1,n_tasks), 0.5*np.ones(n_tasks-1), label=f"random", c='black')
        plt.legend()
        plt.xlabel("Task number")
        plt.ylabel("Mean backwards accuracy")
        plt.savefig(f"test_backwards_{exp_name}_{task_name}.jpg")
